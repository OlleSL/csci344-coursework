import React, { useEffect, useState } from "react";
import { getDataFromServer } from "../server-requests";

export default function Stories({ token }) {
    const [stories, setStories] = useState([]);

    useEffect(() => {
        getDataFromServer(token, "/api/stories").then(setStories);
    }, []);

    return (
        <div className="flex gap-4 overflow-x-auto mb-4 p-2 bg-white border rounded">
            {stories.map((story) => (
                <img key={story.id} src={story.user.thumb_url} className="w-14 h-14 rounded-full" alt="story" />
            ))}
        </div>
    );
}
